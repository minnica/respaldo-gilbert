$("#toggle").click(function() {
	$(this).toggleClass("open");
	$("#menu").toggleClass("opened");
});